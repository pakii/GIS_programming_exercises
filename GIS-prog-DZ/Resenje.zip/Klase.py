#!/usr/bin/env python2
# -*- coding: utf-8 -*-


class Nepokretnost:

    def __init__(self, id, tip, povrsina, zakup, adresa):
        self.id = id
        self.povrsina = povrsina
        self.zakup = zakup
        self.adresa = adresa
        self.tip = tip

    def __str__(self):
        return "Tip: {0:s}, Povrsina: {1:s}, Cena zakupa: {2:s}, Adresa: {3:s}".format(str(self.tip), str(self.povrsina), str(self.zakup), str(self.adresa))

class Kuca(Nepokretnost):

    def __init__(self, id, povrsina, zakup, adresa):
        Nepokretnost.__init__(self, id, "Kuća", povrsina, zakup, adresa)



class Stan(Nepokretnost):

    def __init__(self, id, povrsina, zakup, adresa, sprat, gradnja):
        Nepokretnost.__init__(self, id, "Stan", povrsina, zakup, adresa)
        self.sprat = sprat
        self.gradnja = gradnja

    def __str__(self):
        return Nepokretnost.__str__(self) + (", Sprat: {0:s}, Gradnja: {1:s}".format(str(self.sprat), str(self.gradnja)))


class Lokal(Nepokretnost):

    def __init__(self, id, povrsina, zakup, adresa):
        Nepokretnost.__init__(self, id, "Lokal", povrsina, zakup, adresa)
        self.koriscenje = list()

    def dodajKoriscenje(self, k):
        self.koriscenje.append(k)

    def __str__(self):
        kor = ""
        for k in self.koriscenje:
            kor += str(k) + ", "
        return Nepokretnost.__str__(self) + ", Korišćenje: {0:s}".format(kor)

class Vlasnik:

    def __init__(self, ime, prezime, jmbg):
        self._jmbg = jmbg
        self.ime = ime
        self.prezime = prezime
        self.nepokretnosti = list()

    def set_jmbg(self, jmbg):
        self._jmbg = jmbg

    def get_jmbg(self):
        return self._jmbg

    def addNepokretnost(self, k):
        self.nepokretnosti.append(k)

    def getNepokretnosti(self,nep):
        return self.nepokretnosti

    def __str__(self):
        nep = "\n"
        for n in self.nepokretnosti:
            nep += str(n) + "\n"
        return "Ime: {0:s}, Prezime: {1:s}, JMBG: {2:s}".format(str(self.ime), str(self.prezime), str(self.get_jmbg())) +"\nNepokretnosti:" + nep