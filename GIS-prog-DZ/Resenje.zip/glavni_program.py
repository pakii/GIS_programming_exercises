# -*- coding: utf-8 -*-
import csv
import random


from Klase import Kuca
from Klase import Stan
from Klase import Lokal
from Klase import Vlasnik


print("Program je započet")
nekretnine = list()
vlasnici = list()

# ucitavanje kuca i kreiranje objekata
k = open("Kuce.csv", "r")
csv_k = list(csv.reader(k)) # ucitavanje kao liste listi
for kuca in csv_k[1:]: # preskakanje zaglavlja csv fajla
    kuca_obj = Kuca( kuca[0], kuca[1], kuca[2], kuca[3])
    nekretnine.append(kuca_obj)
k.close()

# ucitavanje stanova i kreiranje objekata
s = open("Stanovi.csv", "r")
csv_s = list(csv.reader(s)) # ucitavanje kao liste listi
for stan in csv_s[1:]: # preskakanje zaglavlja csv fajla
    stan_obj = Stan( stan[0], stan[1], stan[2], stan[3],  stan[4], stan[5])
    nekretnine.append(stan_obj)
s.close()

# ucitavanje lokala i kreiranje objekata
l = open("Lokali.csv", "r")
csv_l = list(csv.reader(l)) # ucitavanje kao liste listi
for lokal in csv_l[1:]: # preskakanje zaglavlja csv fajla
    lokal_obj = Lokal(lokal[0], lokal[1], lokal[2], lokal[3])
    for i in range(4,len(lokal)):   # dodavanje tipova koriscenja
        lokal_obj.dodajKoriscenje(lokal[i])
    nekretnine.append(lokal_obj)
l.close()

# ucitavanje vlasnika i kreiranje objekata
v = open("Vlasnici.csv", "r")
csv_v = list(csv.reader(v)) # ucitavanje kao liste listi
for vlasnik in csv_v[1:]: # preskakanje zaglavlja csv fajla
    vlasnik_obj = Vlasnik(vlasnik[0], vlasnik[1], vlasnik[2])
    vlasnici.append(vlasnik_obj)
l.close()

# nasumicno razvrstavanje nepokretnosti
for n in nekretnine:
    vlasnici[random.randint(0, 2)].addNepokretnost(n)

# ispis informacija o vlasnicima i nepokretnostima

for v in vlasnici:
    print v